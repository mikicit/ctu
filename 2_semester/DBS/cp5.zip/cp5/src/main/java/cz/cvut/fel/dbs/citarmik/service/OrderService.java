package cz.cvut.fel.dbs.citarmik.service;

public class OrderService {
    public void createOrder() {

    }
}
