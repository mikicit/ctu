package cz.cvut.fel.dbs.citarmik.entity;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "Employee")
public class Employee extends Person {
    @Id
    @SequenceGenerator(name="employee_employee_id_seq",
            sequenceName="employee_employee_id_seq",
            allocationSize=1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator="employee_employee_id_seq")
    @Column(name = "employee_id", updatable = false)
    private long employeeId;
    @Column(name = "card_number", nullable = false, unique = true)
    private Integer cardNumber;
    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "position_id")
    private EmployeePosition position;
    @OneToOne(cascade = CascadeType.REMOVE)
    @JoinColumn(name = "person_id", nullable = false)
    private Person person;
    @ManyToOne()
    @JoinColumn(name = "department_id", nullable = false)
    private Department department;
    @OneToOne(mappedBy = "employee")
    private Supervisor supervisor;
    @OneToMany(mappedBy = "supervisor")
    private List<Supervisor> subordinates = new ArrayList<>();

    public long getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

    public long getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(Integer cardNumber) {
        this.cardNumber = cardNumber;
    }

    public EmployeePosition getPosition() {
        return position;
    }

    public void setPosition(EmployeePosition position) {
        this.position = position;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public Supervisor getSupervisor() {
        return supervisor;
    }

    public void setSupervisor(Supervisor supervisor) {
        this.supervisor = supervisor;
    }

    public List<Supervisor> getSubordinates() {
        return subordinates;
    }

    public void setSubordinates(List<Supervisor> subordinates) {
        this.subordinates = subordinates;
    }
}
