package cz.cvut.fel.dbs.citarmik.entity;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "Client")
public class Client extends Person {
    @Id
    @SequenceGenerator(name="client_client_id_seq",
            sequenceName="client_client_id_seq",
            allocationSize=1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator="client_client_id_seq")
    @Column(name = "client_id", updatable = false)
    private long clientId;
    @Column(name = "pass_id", length = 32, nullable = false, unique = true)
    private String passId;
    @OneToOne(cascade = CascadeType.REMOVE)
    @JoinColumn(name = "person_id", unique = true)
    private Person person;
    @Column(name = "bonus_points", nullable = false)
    private Integer bonusPoints;
    @OneToMany(mappedBy = "client", fetch = FetchType.LAZY)
    private List<Order> orders = new ArrayList<>();

    public long getClientId() {
        return clientId;
    }

    public void setClientId(long clientId) {
        this.clientId = clientId;
    }

    public String getPassId() {
        return passId;
    }

    public void setPassId(String passId) {
        this.passId = passId;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public Integer getBonusPoints() {
        return bonusPoints;
    }

    public void setBonusPoints(Integer bonusPoints) {
        this.bonusPoints = bonusPoints;
    }

    public List<Order> getOrders() {
        return orders;
    }

    public void setOrders(List<Order> orders) {
        this.orders = orders;
    }
}
